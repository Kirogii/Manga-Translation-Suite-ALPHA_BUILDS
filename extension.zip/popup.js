document.getElementById('setBtn').addEventListener('click', async () => {
  const endpoint = document.getElementById('endpoint').value;
  await chrome.storage.local.set({ apiEndpoint: endpoint });
  alert('Endpoint saved!');
});

document.getElementById('translateBtn').addEventListener('click', async () => {
  // Inject content.js and trigger window.androidextRunOCR in the active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  // First, inject content.js (if not already injected)
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });
  // Then, call the global OCR trigger function
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => { window.androidextRunOCR && window.androidextRunOCR(); }
  });
});

// Overlay mode dropdown logic
const overlayModeSelect = document.getElementById('overlayMode');
if (overlayModeSelect) {
  // Set dropdown to saved value
  const saved = localStorage.getItem('androidext_overlay_mode') || 'english';
  overlayModeSelect.value = saved;
  overlayModeSelect.addEventListener('change', () => {
    localStorage.setItem('androidext_overlay_mode', overlayModeSelect.value);
    // Also set a global variable for content.js to pick up immediately
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (mode) => { window.androidextOverlayMode = mode; },
        args: [overlayModeSelect.value]
      });
    });
  });
}

// OCR model dropdown logic
const ocrModelSelect = document.getElementById('ocrModel');
if (ocrModelSelect) {
  // Set dropdown to saved value
  const savedOcr = localStorage.getItem('androidext_ocr_model') || 'default';
  ocrModelSelect.value = savedOcr;
  ocrModelSelect.addEventListener('change', async () => {
    localStorage.setItem('androidext_ocr_model', ocrModelSelect.value);
    // API request for OCR model change is handled on "Save Settings"
  });
}

// Populate OCR models from backend
async function populateOcrModels() {
  const ocrModelSelect = document.getElementById('ocrModel');
  let endpoint = localStorage.getItem('apiEndpoint') || document.getElementById('endpoint').value || 'http://localhost:8000';
  endpoint = endpoint.replace(/\/$/, '');
  try {
    const res = await fetch(endpoint + '/list_ocrmodels');
    const data = await res.json();
    if (data.ocr_models && Array.isArray(data.ocr_models)) {
      ocrModelSelect.innerHTML = data.ocr_models.map(([id, label]) => `<option value="${id}">${label}</option>`).join('');
      // Set to saved value if present
      const savedOcr = localStorage.getItem('androidext_ocr_model') || 'default';
      if (data.ocr_models.some(([n]) => n === savedOcr)) {
        ocrModelSelect.value = savedOcr;
      }
    }
  } catch (e) {
    // fallback to default
    ocrModelSelect.innerHTML = '<option value="default">YOLO + manga_ocr (2GB)</option><option value="hal-utokyo/MangaLMM">MangaLMM (HuggingFace) (10-15GB)</option>';
  }
  // Set current OCR model from backend if available
  try {
    const res = await fetch(endpoint + '/current_ocrmodel');
    const data = await res.json();
    if (data.current_ocr_model) {
      ocrModelSelect.value = data.current_ocr_model;
      localStorage.setItem('androidext_ocr_model', data.current_ocr_model);
    }
  } catch (e) {}
}
if (document.getElementById('ocrModel')) populateOcrModels();

// Add OCR model (HuggingFace only) from popup
window.addEventListener('DOMContentLoaded', function() {
  const addOcrBtn = document.getElementById('addOcrModelBtn');
  if (addOcrBtn) {
    addOcrBtn.onclick = async function() {
      const modelId = prompt('Enter HuggingFace model id (e.g. hal-utokyo/MangaLMM):');
      const modelName = prompt('Enter display name for this model:');
      if (!modelId || !modelName) return;
      let endpoint = localStorage.getItem('apiEndpoint') || document.getElementById('endpoint').value || 'http://localhost:8000';
      endpoint = endpoint.replace(/\/$/, '');
      await fetch(endpoint + '/add_ocr_model', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: modelId, name: modelName })
      });
      await populateOcrModels();
    };
  }
});

// Listen for progress updates from the content script
window.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'ANDROIDEXT_PROGRESS') {
    const { current, total } = event.data;
    const progressElem = document.getElementById('progress-glow');
    if (progressElem) {
      progressElem.textContent = `${current} / ${total}`;
      progressElem.style.display = 'block';
      if (current === total) {
        setTimeout(() => progressElem.style.display = 'none', 1200);
      }
    }
  }
});

document.addEventListener('DOMContentLoaded', function() {
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsModal = document.getElementById('settingsModal');
  const closeSettings = document.getElementById('closeSettings');
  // Save Settings button now triggers all API requests
  const saveSettings = document.getElementById('saveSettings');
  const modelSelect = document.getElementById('modelSelect');
  const ttsLang = document.getElementById('ttsLang');
  const textboxMode = document.getElementById('textboxMode');

  // Fetch models from backend
  async function populateModels() {
    let endpoint = localStorage.getItem('androidext_settings') ? JSON.parse(localStorage.getItem('androidext_settings')).endpoint : null;
    if (!endpoint) {
      endpoint = localStorage.getItem('apiEndpoint') || document.getElementById('endpoint').value || 'http://localhost:8000';
    }
    endpoint = endpoint.replace(/\/$/, '');
    try {
      const res = await fetch(endpoint + '/list_aimodels');
      const data = await res.json();
      if (data.models && Array.isArray(data.models)) {
        modelSelect.innerHTML = data.models.map(([name, ram]) => `<option value="${name}">${name} (${ram})</option>`).join('');
        // Set to saved value if present
        const settings = JSON.parse(localStorage.getItem('androidext_settings') || '{}');
        if (settings.model && data.models.some(([n]) => n === settings.model)) {
          modelSelect.value = settings.model;
        }
      }
    } catch (e) {
      // fallback to default
      modelSelect.innerHTML = '<option value="cyy0/JaptoEnBetterMTL-2">cyy0/JaptoEnBetterMTL-2 (2GB)</option><option value="Helsinki-NLP/opus-mt-ja-en">Helsinki-NLP/opus-mt-ja-en (1.2GB)</option>';
    }
  }
  populateModels();

  // Load settings from localStorage
  const settings = JSON.parse(localStorage.getItem('androidext_settings') || '{}');
  if (settings.model) modelSelect.value = settings.model;
  if (settings.ttsLang) ttsLang.value = settings.ttsLang;
  if (settings.textboxMode) textboxMode.value = settings.textboxMode;

  settingsBtn.onclick = () => { settingsModal.style.display = 'flex'; };
  closeSettings.onclick = () => { settingsModal.style.display = 'none'; };
  if (saveSettings) {
    saveSettings.onclick = async function() {
      localStorage.setItem('androidext_settings', JSON.stringify({
        model: modelSelect.value,
        ttsLang: ttsLang.value,
        textboxMode: textboxMode.value
      }));
      settingsModal.style.display = 'none';
      window.postMessage({ type: 'ANDROIDEXT_SETTINGS_UPDATE', settings: {
        model: modelSelect.value,
        ttsLang: ttsLang.value,
        textboxMode: textboxMode.value
      } }, '*');
      // Now send OCR model and GGUF model API requests
      let endpoint = localStorage.getItem('apiEndpoint') || document.getElementById('endpoint').value || 'http://localhost:8000';
      endpoint = endpoint.replace(/\/$/, '');
      const ocrModel = localStorage.getItem('androidext_ocr_model') || 'default';
      try {
        await fetch(endpoint + '/set_ocr_model', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ocr_model: ocrModel })
        });
      } catch (e) {}
    };
  }

  // Model change confirmation
  modelSelect.onchange = function() {
    const selected = models.find(([name]) => name === modelSelect.value);
    if (!selected) return;
    if (confirm(`Are you sure?\n\nAI models take a lot of RAM. If you're using CUDA, make sure your GPU can fit this AI model. If you're on CPU, make sure you have enough RAM.\n\nModel: ${selected[0]}\nRAM Used: ${selected[1]}`)) {
      // Send API request to /get_aimodel
      fetch('/get_aimodel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: selected[0] })
      });
    } else {
      // Revert selection
      modelSelect.value = settings.model || models[0][0];
    }
  };

  // First load: ask for offline dictionary support
  if (!localStorage.getItem('androidext_offline_dict_prompted')) {
    setTimeout(() => {
      if (confirm('Do you want to enable offline Japanese dictionary support? (JMdict will be used, no API keys required)')) {
        localStorage.setItem('androidext_offline_dict', '1');
      } else {
        localStorage.setItem('androidext_offline_dict', '0');
      }
      localStorage.setItem('androidext_offline_dict_prompted', '1');
    }, 500);
  }
});
